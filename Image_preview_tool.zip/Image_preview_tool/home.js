function onEventList(e) {
    e.stopPropagation();
    e.preventDefault();
}
function drop(e) {
    var dt = e.dataTransfer;
    var files = dt.files;
    [...files].forEach(previewFile);
}
let dropHere = document.getElementById("dropHere");
["dragenter", "dragover", "dragleave", "drop"].forEach(eventName => {
    dropHere.addEventListener(eventName, onEventList, false);
    document.body.addEventListener(eventName, onEventList, false);
});
dropHere.addEventListener("drop", drop, false);
function loadImage() {
    const url = document.getElementById("imgUrl").value;
    addImage(url);
}
function addImage(src) {
    let img = document.createElement("img");
    img.src = src;
    const previewElem = document.getElementById("previewHere");
    previewElem.removeChild(previewElem.children[0]);
    previewElem.appendChild(img);
}
function previewFile(file) {
    let reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onloadend = () => {
        let img = document.createElement("img");
        img.src = reader.result;
        const previewElem = document.getElementById("previewHere");
        previewElem.removeChild(previewElem.children[0]);
        previewElem.appendChild(img);
    };
}
